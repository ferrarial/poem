package ch.supsi.netlab.LogService;

import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;

public class NetworkTrafficThread {

	public static int RECORD_INTERVAL = 100;
	
	
	public boolean wiFiEnabled = false;
	public boolean wifiConnected = false;
	public String ESSID ;
	public String BSSID;
	
	
	public boolean isCelDataConnected = false;
	
	
	
	public WifiManager wm;
	public TelephonyManager tel;
	
	public boolean RUN = true;
	
	public  NetworkTrafficThread(WifiManager _wm, TelephonyManager _tel){
		wm = _wm;
		tel = _tel;
		
		
	}
	
	
	
	public void doRecording(){
		this.wiFiEnabled = wm.isWifiEnabled();
		if(this.wiFiEnabled){
			//wm.g
		}
	}
	
	
	
	
	class RecordThread implements Runnable{

		public void run() {
				while(RUN){
					
					
					
					
					try {
						Thread.sleep(RECORD_INTERVAL);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
		}
		
		

		
		
	}
}
