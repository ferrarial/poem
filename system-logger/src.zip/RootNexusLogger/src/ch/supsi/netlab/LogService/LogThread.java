package ch.supsi.netlab.LogService;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import android.content.Context;
import ch.supsi.netlab.SysLogger.CPU;
import ch.supsi.netlab.SysLogger.LogCatListener;
import ch.supsi.netlab.SysLogger.Memory;
import ch.supsi.netlab.SysLogger.Network;
import ch.supsi.netlab.SysLogger.OutputParser;
import ch.supsi.netlab.SysLogger.ScreenLogger;
import ch.supsi.netlab.Utilities.Constants;
import ch.supsi.netlab.procparser.ProcParser;
import ch.supsi.netlab.procparser.UsageType;

public class LogThread implements Runnable {
	
	
	
	

	public static int INTERVAL = 1000;
	public static boolean RUN = false;
	
	public BufferedWriter buf = null;
	public boolean bufLock = false;
	
	
	private ProcParser pars;
	private int pid;
	
	
	private CPU cpu;
	private Memory mem;
	private Network net;
	private LogCatListener logcat;
	private ScreenLogger screen;
	
	//output buffers
	private OutputParser cpuOutput;
	private OutputParser memoryOutput;

	private OutputParser wifiOutput;
	private OutputParser mobileOutput;
	
	
	private OutputParser screenOutput;
	
	Process proc = null;
	private Context cont;
	//Process proc = Runtime.getRuntime().exec("strace -p "+pid+" -tt -o ");
	
	public LogThread(ProcParser _pars, int _pid, Context _cont){
		pars = _pars;
		pid = _pid;
		cont = _cont;
		logcat = new LogCatListener();
		//new Thread(new StraceWrapper()).start();
		
	}
	
	public void run() {
		RUN = true;
		
		cpuOutput = new OutputParser(Constants.getOutputCPUFile());
		cpu = new CPU(cpuOutput);
		
		
		memoryOutput = new OutputParser(Constants.getOutputMemoryFile());
		mem = new Memory(memoryOutput);
		
		mobileOutput = new OutputParser(Constants.getOutputMobileFile());
		wifiOutput = new OutputParser(Constants.getOutputWifiFile());
		
		net = new Network(cont, mobileOutput, wifiOutput);
		
		screenOutput = new OutputParser(Constants.getFileScreenBrightnessFile());
		screen = new ScreenLogger(screenOutput, cont);
		
		logcat.startLogcatListener();
		while(RUN){
			try {
				Thread.sleep(INTERVAL);
				cpu.logCPU();
				mem.logMemory();
				net.logTelephoneStatus();
				net.logWifiStatus();
				screen.logScreen();
				//System.out.println("Screen Bring: "+android.provider.Settings.System.getString(cont.getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS));
				
			} catch (InterruptedException e) { e.printStackTrace(); }
			
		}
		
		logcat.stopLoggin();
		cpuOutput.close();
		cpu = null;
		
		memoryOutput.close();
		mem = null;
		
		wifiOutput.close();
		mobileOutput.close();
		net = null;
		
		screenOutput.close();
		screen = null;
		
	}
	
	
	public void stopThread(){
		RUN = false;
		//proc.destroy();
	}
	
	

	





	
	

}
