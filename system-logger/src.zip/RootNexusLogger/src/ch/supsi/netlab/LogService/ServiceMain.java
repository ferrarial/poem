package ch.supsi.netlab.LogService;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import ch.supsi.netlab.Utilities.Constants;
import ch.supsi.netlab.procparser.ProcParser;
import ch.supsi.netlab.procparser.Utils;
import android.R;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.IBinder;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ServiceMain extends Service {

	private static int pid;
	private static boolean recording = false;
	private static ProcParser pars = null;
	private static LogThread  lthread = null;
	
	
	public WifiManager wm;
	
	public static Resources res;
	
	public void onCreate(){
		super.onCreate();
		
		
		try {
			Runtime.getRuntime().exec("su");
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		

			pid = Utils.getPid();

	}
	
	
	//getter and setter
	public int getProcessId(){ return pid; }
	public boolean getRecordingStatus(){ return recording; }
	
	
	public void startStopRecording(){
		if(lthread == null && !recording){
			recording = true;
			Constants.setTimestamp();
			lthread = new LogThread(pars, pid, this);
			new Thread(lthread).start();
			System.out.println("Start recording");
		}else{
			if(lthread != null) lthread.stopThread();
			recording = false;
			lthread =  null;
			System.out.println("stop recording");
		}
	}
	/**
	 * Bind
	 */
	private final IBinder mBinder = new LocalBinder();

	public IBinder onBind(Intent intent) { return mBinder; }

	public class LocalBinder extends Binder {
		public ServiceMain getService() {
			// Return this instance of LocalService so clients can call public
			// methods
			return ServiceMain.this;
		}
	}
	
	
	
	
	

}
