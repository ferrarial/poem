package ch.supsi.netlab.procparser;

public enum UsageType {
        CPU, MEMORY, DISK, NETWORK, PARTITION
}