package ch.supsi.netlab.ledtoggle;

import java.io.IOException;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.os.Build;

@SuppressLint("NewApi")
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class ToggleManager {
	private static Camera cam = null;

	public static void ledToggle() {
		cam = Camera.open();
		try {
			cam.setPreviewTexture(new SurfaceTexture(0));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 cam.startPreview();
		 Parameters p = cam.getParameters();
		 p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
		 cam.setParameters(p);
		 
		 try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 cam.stopPreview();
		 cam.release();
		 cam = null;
		 
		 
		    
		    
	}

}
