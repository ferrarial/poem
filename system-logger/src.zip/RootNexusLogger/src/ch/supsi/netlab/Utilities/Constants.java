package ch.supsi.netlab.Utilities;

import java.io.File;

import android.os.Environment;

public class Constants {

	public static boolean DEBUG_LOG = false;
	
	public static String OUTPUT_FILE_HEADER = "log_";
	public static String OUTPUT_SYSCALL_FILE = "sc_";
	public static String OUPUT_FILE_FOOTER = ".txt";
	public static String OUTPUT_DIR = "logger";
	
	public static long TIME_STAMP = 0;
	
	
	public static void setTimestamp(){
		TIME_STAMP = System.currentTimeMillis();
	}
	public static String getOuputDir(){
		String dir = "/sdcard/"+OUTPUT_DIR;
		//String dir = Environment.getExternalStorageDirectory()+"/"+OUTPUT_DIR;
		File f = new File(dir);
		if(!f.isDirectory()) f.mkdir();
		
		String dir2 = "/sdcard/"+OUTPUT_DIR+"/"+TIME_STAMP;
		f = new File(dir2);
		if(!f.isDirectory()) f.mkdir();
		return dir2;
		
	}
	
	public static String getOutputCPUFile(){
		String dir = getOuputDir();
		String file = dir+"/cpu_"+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
		
	}

	
	public static String getOutputMemoryFile(){
		String dir = getOuputDir();
		String file = dir+"/memory_"+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
		
	}
	
	
	public static String getOutputWifiFile(){
		String dir = getOuputDir();
		String file = dir+"/wifi_"+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
	}
	
	public static String getOutputMobileFile(){
		String dir = getOuputDir();
		String file = dir+"/mobile_"+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
		
	}
	
	public static String getLogcatFileMobileFile(){
		String dir = getOuputDir();
		String file = dir+"/logcat_"+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
		
	}
	
	public static String getFileScreenBrightnessFile(){
		String dir = getOuputDir();
		String file = dir+"/screen_"+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
		
	}
	
	
	
	public static String getOtputFile(){
		String dir = getOuputDir();
		String file = dir+"/"+OUTPUT_FILE_HEADER+TIME_STAMP+OUPUT_FILE_FOOTER;
		return file;
	}
	

}
