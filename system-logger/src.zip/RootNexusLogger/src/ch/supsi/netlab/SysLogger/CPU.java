package ch.supsi.netlab.SysLogger;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import ch.supsi.netlab.Utilities.Constants;

public class CPU {

	public static String CPU_CURRENT_FREQ = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq";
	public static String CPU_MIN_FREQ = "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq";
	public static String CPU_MAX_FREQ = "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq";

	
	private int cpuMaxFreq = 0;
	private int cpuMinFreq = 0;
	private int cpuFreq = 0;
	
	private OutputParser out;
	public CPU(OutputParser _out){
		out = _out;
	}
	
	public void logCPU(){
		cpuMaxFreq = this.parseSingleFileLine(CPU_MAX_FREQ);
		cpuMinFreq = this.parseSingleFileLine(CPU_MIN_FREQ);	
		cpuFreq = this.parseSingleFileLine(CPU_CURRENT_FREQ);
		if(Constants.DEBUG_LOG)System.out.println("CPU: "+cpuFreq+" "+cpuMaxFreq+" "+cpuMinFreq);
		
		out.logString(cpuFreq+" "+cpuMaxFreq+" "+cpuMinFreq);
	}
	
	
	
	public int parseSingleFileLine(String path){
		try {
			BufferedReader read = new BufferedReader(new FileReader(path));
			//System.out.println(read.readLine());
			int value = Integer.valueOf(read.readLine());
			//System.out.println(read.readLine());
			read.close();
			return value;
		} catch (FileNotFoundException e) { e.printStackTrace();
		} catch (IOException e) { e.printStackTrace(); }
		return -1;

	}
	
	
	
}
