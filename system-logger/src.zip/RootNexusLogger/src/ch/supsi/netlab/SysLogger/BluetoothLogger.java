package ch.supsi.netlab.SysLogger;

public class BluetoothLogger {
//TBD
	
	
}
