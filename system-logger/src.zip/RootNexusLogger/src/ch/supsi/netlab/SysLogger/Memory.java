package ch.supsi.netlab.SysLogger;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import ch.supsi.netlab.Utilities.Constants;

public class Memory {

	private String MEM_FILE = "/proc/meminfo";
	private OutputParser out;
	
	public Memory(OutputParser _out){
		out = _out;
	}
	
	
	public void logMemory(){
		try {
			BufferedReader buf = new BufferedReader(new FileReader(MEM_FILE));
			String memTot = buf.readLine();
			String memFree = buf.readLine();
			buf.close();
			
			String[] mt = memTot.split(" ");
			String[] mf = memFree.split(" ");
			String mta = "0";
			String mfa = "0";
			for(int i=2; i < mt.length; i++){
				if(mt[i].compareTo(" ") != 0){
					 if(mt[i].length() > 0){
						 mta = mt[i];
						 break;
					 }
				}
			}
			
			for(int i=2; i < mf.length; i++){
				if(mf[i].compareTo(" ") != 0){
					if(mf[i].length() > 0){
						mfa = mf[i];
						break;
					}
				}
			}

			
			//System.out.println("Log Memory: ");
			if(Constants.DEBUG_LOG)System.out.println("Memory: "+mta+"\t"+mfa);
			out.logString(mta+"\t"+mfa);
		} catch (FileNotFoundException e) { e.printStackTrace();
		} catch (IOException e) { e.printStackTrace(); }

	}
}
