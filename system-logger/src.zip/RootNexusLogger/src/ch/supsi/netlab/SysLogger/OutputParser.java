package ch.supsi.netlab.SysLogger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class OutputParser {

	private BufferedWriter buf = null;
	
	
	public OutputParser(String outputFile){
		try {
			buf = new BufferedWriter(new FileWriter(outputFile));
		} catch (IOException e) { e.printStackTrace(); }
	}
	
	
	public void logString(String s){
		if(buf == null){
			System.err.println("Error in OutputParser");
			return;
		}
		try {
			buf.write(s+"\n");
			buf.flush();
		} catch (IOException e) { e.printStackTrace(); }
		
	}
	
	
	public void close(){
		try {
			buf.close();
		} catch (IOException e) { e.printStackTrace(); }
		
		
	}
	
}
