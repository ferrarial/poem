package ch.supsi.netlab.SysLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import ch.supsi.netlab.Utilities.Constants;

public class LogCatListener {

	/*
	 * logcat -v time > /sdcard/logger/logcat_1401734742982.txt

	 */
	public static String LOGCAT_CLEAN = "logcat -c";
	public static String LOGCAT_CALL = "logcat -v time ";
	
	
	private Process p;

	public void startLogcatListener(){
		
	
			try {
				p = Runtime.getRuntime().exec(LOGCAT_CLEAN);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}
	
	

	
	public void stopLoggin(){
		//loggin logcat output
		
		String[] cmd = new String[] { "logcat", "-f", Constants.getLogcatFileMobileFile(), "-v", "time" };
		
		try {
			p = Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("LOGCAT Saved");
		
	}
	
}
