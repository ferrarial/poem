package ch.supsi.netlab.SysLogger;

import ch.supsi.netlab.Utilities.Constants;
import android.content.Context;
import android.location.LocationManager;

public class Sensors {

	private Context cont;
	private OutputParser out;
	
	private LocationManager loc;
	public Sensors(Context _cont, OutputParser _out){
		cont = _cont; out = _out;
	
		loc = (LocationManager) cont.getSystemService(Context.LOCATION_SERVICE);
	}
	
	
	
	public void logGPSStatus(){
		if(!loc.isProviderEnabled(LocationManager.GPS_PROVIDER)){
			
			if(Constants.DEBUG_LOG) System.out.print("GPS down");
			out.logString("0");
			
		}else{
			if(Constants.DEBUG_LOG) System.out.print("GPS up");
			out.logString("1");
		}
		
		
	}
}
