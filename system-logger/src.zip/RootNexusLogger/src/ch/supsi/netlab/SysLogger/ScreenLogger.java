package ch.supsi.netlab.SysLogger;

import ch.supsi.netlab.Utilities.Constants;
import android.content.Context;

public class ScreenLogger {

	private OutputParser out;
	private Context cont;
	
	public ScreenLogger(OutputParser _out, Context _cont){
		out = _out; cont = _cont;
		//android.provider.Settings.System.
	}
	
	
	public void logScreen(){
		String bring = 	android.provider.Settings.System.getString(cont.getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS);
		
		if(Constants.DEBUG_LOG) System.out.println(bring);
		out.logString(bring);
	}
	
	
}
