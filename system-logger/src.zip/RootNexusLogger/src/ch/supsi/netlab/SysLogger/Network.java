package ch.supsi.netlab.SysLogger;

import java.io.File;

import ch.supsi.netlab.Utilities.Constants;
import android.content.Context;
import android.net.TrafficStats;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;

public class Network {

	public TelephonyManager tManager;
	public WifiManager wManager;
	public TrafficStats traffic;
	
	//outputs
	private OutputParser mobileO;
	private OutputParser wifiO;
	
	public Network(Context cont, OutputParser _mobile, OutputParser _wifi){
		tManager = (TelephonyManager)cont.getSystemService(cont.TELEPHONY_SERVICE);
		wManager = (WifiManager)cont.getSystemService(cont.WIFI_SERVICE);
		mobileO = _mobile; wifiO = _wifi;
		
	}
	
	
	long pastMobileTransmission = 0;
	long pastMobileReception = 0;
	public void logTelephoneStatus(){
		
		
		if(tManager != null){
			if(tManager.getDataState() == TelephonyManager.DATA_CONNECTED){
				mobileO.logString("1");
				if(Constants.DEBUG_LOG) System.out.println("Disconnected");
				return;
			}
			
			if(tManager.getSimState() == tManager.SIM_STATE_ABSENT){
				mobileO.logString("2");
				if(Constants.DEBUG_LOG) System.out.println("Sim Absent");
				return;
			}
			
			String phoneOperator = tManager.getNetworkOperator();
			int callState = tManager.getCallState();
			long mobileTransmission = TrafficStats.getMobileTxBytes();
			long mobileReception = TrafficStats.getMobileRxBytes();
			
			long realTX = mobileTransmission - pastMobileTransmission;
			long realRX = mobileReception - pastMobileReception;
			
			pastMobileReception = mobileReception;
			pastMobileTransmission = mobileTransmission;
			
			if(Constants.DEBUG_LOG) System.out.println("Phone Status: "+phoneOperator+" "+realTX+" "+realRX+" "+callState);
			mobileO.logString(phoneOperator+" "+realTX+" "+realRX+" "+callState);
			
		}else{
			if(Constants.DEBUG_LOG)System.out.println("Network unavailable on the phone");
			mobileO.logString("0");
		}
	}
	
	long pastWifiTransmission = 0;
	long pastWifiReception = 0;
	
	public void logWifiStatus(){
		//System.out.println("LOG WIFI");
		if(wManager.isWifiEnabled()){
			/*if(wManager.disconnect()){
				if(Constants.DEBUG_LOG)System.out.println("Wifi disconnected");
				wifiO.logString("1");
				
			}else{*/
			WifiInfo winf = wManager.getConnectionInfo();
			if(winf == null){
					if(Constants.DEBUG_LOG)System.out.println("Wifi disconnected");
					wifiO.logString("1");
			}else{
				String essid = winf.getSSID();
				String bssid = winf.getBSSID();
				int rssi = winf.getRssi();
				
				long wifiTransmission = TrafficStats.getTotalTxBytes() - TrafficStats.getMobileTxBytes();
				long wifiReception = TrafficStats.getTotalRxBytes() - TrafficStats.getMobileRxBytes();
				
				long realTX = wifiTransmission - pastWifiTransmission;
				long realRX = wifiReception - pastWifiReception;
				
				pastWifiReception = wifiReception;
				pastWifiTransmission = wifiTransmission;
				if(Constants.DEBUG_LOG)System.out.println("WiFI: "+essid+" "+bssid+" "+rssi+" "+realTX+" "+realRX);
				wifiO.logString(essid+" "+bssid+" "+rssi+" "+realTX+" "+realRX);
			}
			
		}else{
			if(Constants.DEBUG_LOG)System.out.println("Wifi power-down");
			wifiO.logString("0");
		}
		
	}
	
	
	
}
