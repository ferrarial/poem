package com.example.rootnexuslogger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ch.supsi.netlab.LogService.ServiceMain;
import ch.supsi.netlab.LogService.ServiceMain.LocalBinder;
import ch.supsi.netlab.ledtoggle.ToggleManager;
import ch.supsi.netlab.procparser.ProcParser;
import ch.supsi.netlab.procparser.UsageType;
import ch.supsi.netlab.procparser.Utils;

import android.os.Bundle;
import android.os.IBinder;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {

	//public ProcParser pars;
	
	ServiceMain mService;
	boolean mBound = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	protected void onStart(){
		super.onStart();
		
	
		
		//bind service
	    Intent intent = new Intent(this, ServiceMain.class);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
		
		
		Button b = (Button) findViewById(R.id.run);
		
		b.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				//ToggleManager.ledToggle();
				System.out.println(mService.getProcessId());
				mService.startStopRecording();
				TextView stat = (TextView)findViewById(R.id.status);
				if(mService.getRecordingStatus()){
					
					stat.setText("Recording");
				}else{
					stat.setText("Sleep");
				}
			}
			
		});
		

		
	}
	
	
	public ArrayList<String> getProcesses(){
		ArrayList<String> s = new ArrayList<String>();
		
		
		
		return s;
		
	}
	
	
    protected void onStop() {
        super.onStop();
        // Unbind from the service
        if (mBound) {
            unbindService(mConnection);
            mBound = false;
        }
    }
	
	
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
	/*class UpdateThread implements Runnable{

		@Override
		public void run() {
			while(true){
				try {
					Thread.sleep(1000);
					ArrayList<String> cpu = pars.gatherUsage(UsageType.CPU);
					
					for(String s: cpu){
						System.out.print(cpu+" ");
					}
					System.out.println();
				} catch (InterruptedException e) {
			
					e.printStackTrace();
				}
				
				
			}
			
		}
		
		
	}*/
	
	
    /** Defines callbacks for service binding, passed to bindService() */
    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            LocalBinder binder = (LocalBinder) service;
            mService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };
    
    
	 private class StableArrayAdapter extends ArrayAdapter<String> {

		    HashMap<String, Integer> mIdMap = new HashMap<String, Integer>();

		    public StableArrayAdapter(Context context, int textViewResourceId,
		        List<String> objects) {
		      super(context, textViewResourceId, objects);
		      for (int i = 0; i < objects.size(); ++i) {
		        mIdMap.put(objects.get(i), i);
		      }
		    }

		    @Override
		    public long getItemId(int position) {
		      String item = getItem(position);
		      return mIdMap.get(item);
		    }

		    @Override
		    public boolean hasStableIds() {
		      return true;
		    }

		  }

}
